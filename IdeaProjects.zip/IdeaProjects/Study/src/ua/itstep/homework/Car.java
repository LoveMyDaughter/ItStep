package ua.itstep.homework;

/**
 * Created by admin on 07.02.2016.
 */
public class Car {
    private int id;
    private int year;
    private int price;
    private int regNumber;
    private String name;
    private String model;
    private String color;

}
